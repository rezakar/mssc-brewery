package com.msscbrewery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsscBreweryApplicationTests {

	@Test
	void contextLoads() {
	}

}
